package proyectofinalpoo;

public class Tablero {
    private final int totalCasillas = 20;

    public int obtenerNuevaPosicion(int actual, int pasos) {
        return (actual + pasos) % totalCasillas;
    }

    public int getTotalCasillas() {
        return totalCasillas;
    }
}
