package proyectofinalpoo;

public class Jugador {
    private String nombre;
    private int posicion;
    private int puntaje;

    public Jugador(String nombre) {
        this.nombre = nombre;
        this.posicion = 0;
        this.puntaje = 0;
    }

    public void avanzar(int pasos) {
        posicion = (posicion + pasos) % 16; // ejemplo de 20 casillas
    }

    public void aumentarPuntaje(int puntos) {
        puntaje += puntos;
    }

    public String getNombre(){ 
        return nombre; 
    }
    public int getPosicion(){
        return posicion; 
    }
    public int getPuntaje(){ 
        return puntaje; 
    }
}
