package proyectofinalpoo;

import java.util.Random;

public class Pregunta {
    private String enunciado;
    private int respuesta;

    public Pregunta(int enunciado) {
         generarPregunta();
    }

    private void generarPregunta() {
        Random rand = new Random();
        int a = rand.nextInt(50);
        int b = rand.nextInt(50);
        int tipo = rand.nextInt(4); // 0: +, 1: -, 2: , 3: /

        switch (tipo) {
            case 0 -> { enunciado = a + " + " + b; respuesta = a + b; }
            case 1 -> { enunciado = a + " - " + b; respuesta = a - b; }
            case 2 -> { enunciado = a + " " + b; respuesta = a * b; }
            case 3 -> {
                b = (b == 0) ? 1 : b; // evitar división entre 0
                a = a - (a % b); // asegurar divisibilidad
                enunciado = a + " / " + b;
                respuesta = a / b;
            }
        }
    }

    public String getEnunciado() { return enunciado; }
    public boolean verificar(int respuestaUsuario) {
        return this.respuesta == respuestaUsuario;
    }
}
